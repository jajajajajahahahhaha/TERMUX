"""
code_sandbox.py
----------------
اجرای کدهای پایتون/شل در یک محیط ایزوله برای تست و دیباگ، با محدودیت زمانی
(timeout) و بدون دسترسی مستقیم به فایل‌سیستم اصلی کاربر مگر داخل پوشه sandbox.

نکته امنیتی: اجرای کد دلخواه همیشه خطر دارد. به همین دلیل:
1) همیشه قبل از اجرا از کاربر تأیید گرفته می‌شود.
2) اجرا داخل یک subprocess جدا با timeout انجام می‌شود (نه exec/eval مستقیم).
3) دایرکتوری کاری اجرا به sandbox_root محدود می‌شود.
"""

from __future__ import annotations

import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

from tools.confirm import ask_user_confirmation

_LanguageT = str  # "python" | "bash"


@dataclass(frozen=True, slots=True)
class SandboxResult:
    """نتیجه یکنواخت اجرای کد در سندباکس."""

    success: bool
    stdout: str
    stderr: str
    return_code: int | None
    timed_out: bool = False


def run_code(
    code: str,
    language: _LanguageT,
    sandbox_root: str,
    timeout_seconds: int = 30,
) -> SandboxResult:
    """
    کد را در سندباکس اجرا می‌کند. زبان‌های مجاز: 'python' و 'bash'.
    """
    if language not in ("python", "bash"):
        return SandboxResult(
            success=False,
            stdout="",
            stderr=f"زبان '{language}' پشتیبانی نمی‌شود. فقط 'python' یا 'bash' مجاز است.",
            return_code=None,
        )

    preview = code if len(code) <= 1000 else code[:1000] + "\n... (ادامه دارد)"
    approved = ask_user_confirmation(
        f"اجرای کد در سندباکس ({language})",
        f"دایرکتوری اجرا: {sandbox_root}\nمحدودیت زمانی: {timeout_seconds} ثانیه\n\nکد:\n{preview}",
    )
    if not approved:
        return SandboxResult(
            success=False,
            stdout="",
            stderr="کاربر اجازه اجرای این کد را نداد.",
            return_code=None,
        )

    Path(sandbox_root).mkdir(parents=True, exist_ok=True)
    suffix = ".py" if language == "python" else ".sh"
    command = [sys.executable] if language == "python" else ["bash"]

    with tempfile.NamedTemporaryFile(
        mode="w",
        suffix=suffix,
        dir=sandbox_root,
        delete=False,
        encoding="utf-8",
    ) as tmp_file:
        tmp_file.write(code)
        tmp_path = tmp_file.name

    try:
        proc = subprocess.run(
            command + [tmp_path],
            cwd=sandbox_root,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
        )
        return SandboxResult(
            success=proc.returncode == 0,
            stdout=proc.stdout,
            stderr=proc.stderr,
            return_code=proc.returncode,
        )
    except subprocess.TimeoutExpired as exc:
        return SandboxResult(
            success=False,
            stdout=exc.stdout or "",
            stderr=f"اجرای کد بیش از {timeout_seconds} ثانیه طول کشید و متوقف شد.",
            return_code=None,
            timed_out=True,
        )
    finally:
        try:
            Path(tmp_path).unlink(missing_ok=True)
        except OSError:
            pass
