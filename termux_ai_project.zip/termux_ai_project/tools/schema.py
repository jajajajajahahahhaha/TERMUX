"""
schema.py
---------
تعریف اسکیمای ابزارها (Function/Tool Calling) به فرمت OpenAI-compatible که
MiniMax از آن پشتیبانی می‌کند. این اسکیما به مدل معرفی می‌شود تا بداند چه
ابزارهایی با چه پارامترهایی در دسترس دارد.
"""

from __future__ import annotations

from typing import Any

TOOLS_SCHEMA: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "create_file",
            "description": "یک فایل جدید در فضای کاری کاربر می‌سازد. اگر فایل از قبل موجود باشد خطا می‌دهد. همیشه قبل از اجرا از کاربر تأیید گرفته می‌شود.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "مسیر کامل یا نسبی فایل"},
                    "content": {"type": "string", "description": "محتوای کامل فایل"},
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "edit_file",
            "description": "یک فایل موجود را ویرایش می‌کند (بازنویسی کامل یا افزودن به انتها). همیشه قبل از اجرا از کاربر تأیید گرفته می‌شود.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "مسیر فایل موجود"},
                    "content": {"type": "string", "description": "محتوای جدید یا محتوای اضافه‌شونده"},
                    "mode": {
                        "type": "string",
                        "enum": ["overwrite", "append"],
                        "description": "overwrite برای بازنویسی کامل، append برای افزودن به انتهای فایل",
                    },
                },
                "required": ["path", "content", "mode"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "delete_file",
            "description": "یک فایل را حذف می‌کند. غیرقابل بازگشت است. همیشه قبل از اجرا از کاربر تأیید گرفته می‌شود.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "مسیر فایلی که باید حذف شود"},
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_code",
            "description": "یک قطعه کد پایتون یا بش را در یک سندباکس ایزوله اجرا می‌کند و خروجی/خطای آن را برمی‌گرداند. برای تست و دیباگ کد استفاده کن. همیشه قبل از اجرا از کاربر تأیید گرفته می‌شود.",
            "parameters": {
                "type": "object",
                "properties": {
                    "code": {"type": "string", "description": "کد کامل قابل اجرا"},
                    "language": {
                        "type": "string",
                        "enum": ["python", "bash"],
                        "description": "زبان کد",
                    },
                },
                "required": ["code", "language"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "web_search",
            "description": "جستجوی وب برای یافتن اطلاعات به‌روز (مستندات، اخبار، رفع خطای کتابخانه‌ها و ...). این عملیات فقط خواندنی است و نیاز به تأیید کاربر ندارد.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "عبارت جستجو"},
                    "max_results": {
                        "type": "integer",
                        "description": "حداکثر تعداد نتایج (پیش‌فرض ۵)",
                    },
                },
                "required": ["query"],
            },
        },
    },
]
