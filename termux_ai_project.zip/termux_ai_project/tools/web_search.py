"""
web_search.py
-------------
جستجوی وب برای دستیار، با استفاده از duckduckgo_search (بدون نیاز به کلید API).
نتایج به صورت لیست دیکشنری ساده (title/url/snippet) برگردانده می‌شوند تا مدل
هوش مصنوعی بتواند آن‌ها را در پاسخ خلاصه/استناد کند.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class SearchHit:
    title: str
    url: str
    snippet: str


@dataclass(frozen=True, slots=True)
class SearchResult:
    success: bool
    query: str
    hits: list[SearchHit] = field(default_factory=list)
    error: str | None = None


def web_search(query: str, max_results: int = 5) -> SearchResult:
    """جستجوی وب را انجام می‌دهد و نتایج خلاصه را برمی‌گرداند. جستجو نیازی به تأیید کاربر ندارد (فقط خواندنی و بی‌خطر است)."""
    try:
        from ddgs import DDGS  # پکیج جدید (نام قبلی: duckduckgo_search)
    except ImportError:
        try:
            from duckduckgo_search import DDGS  # سازگاری با نسخه‌های قدیمی‌تر
        except ImportError:
            return SearchResult(
                success=False,
                query=query,
                error="پکیج جستجو نصب نیست. اجرا کن: pip install ddgs",
            )

    try:
        with DDGS() as ddgs:
            raw_results = list(ddgs.text(query, max_results=max_results))
    except Exception as exc:  # noqa: BLE001 - خطای شبکه/سرویس خارجی را شفاف برمی‌گردانیم
        return SearchResult(success=False, query=query, error=f"خطا در جستجو: {exc}")

    hits = [
        SearchHit(
            title=item.get("title", ""),
            url=item.get("href", ""),
            snippet=item.get("body", ""),
        )
        for item in raw_results
    ]
    return SearchResult(success=True, query=query, hits=hits)
