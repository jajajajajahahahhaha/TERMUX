"""
confirm.py
----------
واسط تأیید تعاملی از کاربر. هر عملیات حساس (ساخت/ادیت/حذف فایل، اجرای کد)
باید قبل از انجام از این تابع عبور کند. هیچ ابزاری اجازه ندارد این مرحله را
دور بزند.
"""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm

console = Console()


def ask_user_confirmation(action_title: str, details: str) -> bool:
    """
    از کاربر برای انجام یک عملیات حساس تأیید می‌گیرد.

    Parameters
    ----------
    action_title: عنوان کوتاه عملیات (مثلاً "ساخت فایل جدید")
    details: توضیح کامل عملیات (مسیر فایل، محتوا، دستور و ...)

    Returns
    -------
    True اگر کاربر تأیید کند، در غیر این صورت False.
    """
    console.print(
        Panel(
            details,
            title=f"⚠️  درخواست تأیید: {action_title}",
            border_style="yellow",
            expand=False,
        )
    )
    try:
        return Confirm.ask("[bold yellow]آیا اجازه انجام این عملیات را می‌دهید؟[/bold yellow]", default=False)
    except (EOFError, KeyboardInterrupt):
        console.print("[red]ورودی کاربر لغو شد؛ عملیات انجام نشد.[/red]")
        return False
