"""
file_ops.py
-----------
عملیات فایل داخل ترموکس: ساخت، ادیت (بازنویسی/append)، و حذف.
قانون طلایی: هیچ عملیاتی بدون تأیید صریح کاربر (ask_user_confirmation) اجرا نمی‌شود.

برای امنیت، مسیرها به یک "workspace root" پیش‌فرض (خانه کاربر) محدود می‌شوند
مگر این‌که کاربر با متغیر محیطی ALLOW_UNSAFE_PATHS=1 این محدودیت را بردارد.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from tools.confirm import ask_user_confirmation

ALLOW_UNSAFE_PATHS: bool = os.environ.get("ALLOW_UNSAFE_PATHS", "0") == "1"
WORKSPACE_ROOT: Path = Path(os.path.expanduser("~")).resolve()


@dataclass(frozen=True, slots=True)
class FileOpResult:
    """نتیجه یکنواخت هر عملیات فایل، برای بازگرداندن به مدل هوش مصنوعی."""

    success: bool
    message: str
    path: str | None = None


class UnsafePathError(Exception):
    """وقتی مسیر درخواستی خارج از workspace امن باشد، این خطا صادر می‌شود."""


def _resolve_safe_path(user_path: str) -> Path:
    """
    مسیر ورودی را resolve می‌کند و در صورت خارج بودن از WORKSPACE_ROOT
    (و نبود ALLOW_UNSAFE_PATHS) خطا می‌دهد. جلوگیری از path traversal
    و دسترسی به مسیرهای حساس سیستم.
    """
    resolved = Path(os.path.expanduser(user_path)).resolve()
    if not ALLOW_UNSAFE_PATHS:
        try:
            resolved.relative_to(WORKSPACE_ROOT)
        except ValueError as exc:
            raise UnsafePathError(
                f"مسیر '{resolved}' خارج از فضای امن ({WORKSPACE_ROOT}) است. "
                "برای اجازه دادن، ALLOW_UNSAFE_PATHS=1 را تنظیم کنید."
            ) from exc
    return resolved


def create_file(path: str, content: str) -> FileOpResult:
    """فایل جدید می‌سازد. اگر فایل از قبل وجود دارد، خطا برمی‌گرداند (بدون تأیید کاربر بازنویسی نمی‌کند)."""
    try:
        safe_path = _resolve_safe_path(path)
    except UnsafePathError as exc:
        return FileOpResult(False, str(exc))

    if safe_path.exists():
        return FileOpResult(
            False,
            f"فایل '{safe_path}' از قبل وجود دارد. برای تغییر آن از عملیات 'edit_file' استفاده کن.",
            str(safe_path),
        )

    preview = content if len(content) <= 800 else content[:800] + "\n... (ادامه دارد)"
    approved = ask_user_confirmation(
        "ساخت فایل جدید",
        f"مسیر: {safe_path}\n\nمحتوا:\n{preview}",
    )
    if not approved:
        return FileOpResult(False, "کاربر اجازه ساخت این فایل را نداد.", str(safe_path))

    safe_path.parent.mkdir(parents=True, exist_ok=True)
    safe_path.write_text(content, encoding="utf-8")
    return FileOpResult(True, f"فایل '{safe_path}' با موفقیت ساخته شد.", str(safe_path))


def edit_file(
    path: str,
    content: str,
    mode: Literal["overwrite", "append"] = "overwrite",
) -> FileOpResult:
    """فایل موجود را ویرایش می‌کند (بازنویسی کامل یا افزودن به انتها)."""
    try:
        safe_path = _resolve_safe_path(path)
    except UnsafePathError as exc:
        return FileOpResult(False, str(exc))

    if not safe_path.exists():
        return FileOpResult(
            False,
            f"فایل '{safe_path}' وجود ندارد. برای ساخت آن از عملیات 'create_file' استفاده کن.",
            str(safe_path),
        )

    old_content = safe_path.read_text(encoding="utf-8", errors="replace")
    preview_old = old_content if len(old_content) <= 400 else old_content[:400] + "\n... (ادامه دارد)"
    preview_new = content if len(content) <= 400 else content[:400] + "\n... (ادامه دارد)"

    approved = ask_user_confirmation(
        f"ویرایش فایل ({'بازنویسی' if mode == 'overwrite' else 'افزودن به انتها'})",
        f"مسیر: {safe_path}\n\nمحتوای فعلی:\n{preview_old}\n\nمحتوای جدید/اضافه‌شونده:\n{preview_new}",
    )
    if not approved:
        return FileOpResult(False, "کاربر اجازه ویرایش این فایل را نداد.", str(safe_path))

    if mode == "append":
        with safe_path.open("a", encoding="utf-8") as f:
            f.write(content)
    else:
        safe_path.write_text(content, encoding="utf-8")

    return FileOpResult(True, f"فایل '{safe_path}' با موفقیت ویرایش شد.", str(safe_path))


def delete_file(path: str) -> FileOpResult:
    """فایل را حذف می‌کند (فقط پس از تأیید صریح کاربر)."""
    try:
        safe_path = _resolve_safe_path(path)
    except UnsafePathError as exc:
        return FileOpResult(False, str(exc))

    if not safe_path.exists():
        return FileOpResult(False, f"فایل '{safe_path}' وجود ندارد.", str(safe_path))

    if safe_path.is_dir():
        return FileOpResult(
            False,
            f"'{safe_path}' یک پوشه است، نه فایل. این ابزار فقط فایل حذف می‌کند.",
            str(safe_path),
        )

    approved = ask_user_confirmation(
        "حذف فایل",
        f"مسیر: {safe_path}\n\n⚠️ این عملیات غیرقابل بازگشت است.",
    )
    if not approved:
        return FileOpResult(False, "کاربر اجازه حذف این فایل را نداد.", str(safe_path))

    safe_path.unlink()
    return FileOpResult(True, f"فایل '{safe_path}' با موفقیت حذف شد.", str(safe_path))
