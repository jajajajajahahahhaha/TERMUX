"""تست‌های واحد برای tools/code_sandbox.py"""

from __future__ import annotations

from pathlib import Path

import pytest

import tools.code_sandbox as code_sandbox


def test_run_python_code_success(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(code_sandbox, "ask_user_confirmation", lambda *_a, **_k: True)

    result = code_sandbox.run_code("print(1 + 1)", "python", str(tmp_path), timeout_seconds=10)

    assert result.success is True
    assert "2" in result.stdout


def test_run_code_denied(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(code_sandbox, "ask_user_confirmation", lambda *_a, **_k: False)

    result = code_sandbox.run_code("print('should not run')", "python", str(tmp_path))

    assert result.success is False
    assert "اجازه" in result.stderr


def test_run_code_invalid_language(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    result = code_sandbox.run_code("echo hi", "ruby", str(tmp_path))

    assert result.success is False
    assert result.return_code is None


def test_run_code_timeout(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(code_sandbox, "ask_user_confirmation", lambda *_a, **_k: True)

    result = code_sandbox.run_code(
        "import time; time.sleep(5)", "python", str(tmp_path), timeout_seconds=1
    )

    assert result.success is False
    assert result.timed_out is True
