"""
تست‌های واحد برای tools/file_ops.py
با استفاده از monkeypatch، تابع تأیید کاربر (ask_user_confirmation) شبیه‌سازی می‌شود
تا تست‌ها بدون ورودی تعاملی واقعی اجرا شوند.
"""

from __future__ import annotations

from pathlib import Path

import pytest

import tools.file_ops as file_ops


@pytest.fixture(autouse=True)
def _use_tmp_as_workspace(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """WORKSPACE_ROOT را به یک دایرکتوری موقت محدود می‌کند تا تست‌ها ایزوله باشند."""
    monkeypatch.setattr(file_ops, "WORKSPACE_ROOT", tmp_path.resolve())


def test_create_file_approved(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(file_ops, "ask_user_confirmation", lambda *_a, **_k: True)
    target = tmp_path / "new_file.txt"

    result = file_ops.create_file(str(target), "hello world")

    assert result.success is True
    assert target.read_text(encoding="utf-8") == "hello world"


def test_create_file_denied(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(file_ops, "ask_user_confirmation", lambda *_a, **_k: False)
    target = tmp_path / "denied_file.txt"

    result = file_ops.create_file(str(target), "should not exist")

    assert result.success is False
    assert not target.exists()


def test_create_file_already_exists(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(file_ops, "ask_user_confirmation", lambda *_a, **_k: True)
    target = tmp_path / "exists.txt"
    target.write_text("original", encoding="utf-8")

    result = file_ops.create_file(str(target), "overwrite attempt")

    assert result.success is False
    assert target.read_text(encoding="utf-8") == "original"


def test_edit_file_overwrite(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(file_ops, "ask_user_confirmation", lambda *_a, **_k: True)
    target = tmp_path / "editable.txt"
    target.write_text("old content", encoding="utf-8")

    result = file_ops.edit_file(str(target), "new content", mode="overwrite")

    assert result.success is True
    assert target.read_text(encoding="utf-8") == "new content"


def test_edit_file_append(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(file_ops, "ask_user_confirmation", lambda *_a, **_k: True)
    target = tmp_path / "appendable.txt"
    target.write_text("line1\n", encoding="utf-8")

    result = file_ops.edit_file(str(target), "line2\n", mode="append")

    assert result.success is True
    assert target.read_text(encoding="utf-8") == "line1\nline2\n"


def test_edit_nonexistent_file_fails(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(file_ops, "ask_user_confirmation", lambda *_a, **_k: True)
    target = tmp_path / "ghost.txt"

    result = file_ops.edit_file(str(target), "content", mode="overwrite")

    assert result.success is False


def test_delete_file_approved(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(file_ops, "ask_user_confirmation", lambda *_a, **_k: True)
    target = tmp_path / "to_delete.txt"
    target.write_text("bye", encoding="utf-8")

    result = file_ops.delete_file(str(target))

    assert result.success is True
    assert not target.exists()


def test_delete_file_denied(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(file_ops, "ask_user_confirmation", lambda *_a, **_k: False)
    target = tmp_path / "keep_me.txt"
    target.write_text("stay", encoding="utf-8")

    result = file_ops.delete_file(str(target))

    assert result.success is False
    assert target.exists()


def test_unsafe_path_rejected(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(file_ops, "ask_user_confirmation", lambda *_a, **_k: True)
    monkeypatch.setattr(file_ops, "ALLOW_UNSAFE_PATHS", False)

    result = file_ops.create_file("/etc/some_outside_path.txt", "malicious")

    assert result.success is False
    assert "خارج از فضای امن" in result.message
