#!/usr/bin/env python3
"""
main.py
-------
نقطه ورود دستیار هوش مصنوعی ترموکس.
یک حلقه چت ساده در ترمینال که با مدل MiniMax (از طریق API سازگار با OpenAI)
صحبت می‌کند و در صورت نیاز، ابزارهای محلی (فایل، سندباکس، جستجو) را با
تأیید کاربر صدا می‌زند.

اجرا:
    export MINIMAX_API_KEY='...'
    python main.py
"""

from __future__ import annotations

import json
import sys
from typing import Any

from openai import APIError, OpenAI
from rich.console import Console
from rich.markdown import Markdown

from config import Settings, load_settings
from tools.code_sandbox import run_code
from tools.file_ops import create_file, delete_file, edit_file
from tools.planner import build_system_prompt
from tools.schema import TOOLS_SCHEMA
from tools.web_search import web_search

console = Console()

Message = dict[str, Any]


def _dispatch_tool_call(name: str, arguments: dict[str, Any], settings: Settings) -> str:
    """
    فراخوانی ابزار درخواستی توسط مدل را اجرا می‌کند و نتیجه را به صورت JSON
    (رشته) برمی‌گرداند تا در پیام role='tool' به مدل بازگردانده شود.

    نکته مهم: خود توابع زیرین (create_file/edit_file/...) از کاربر تأیید
    می‌گیرند؛ این تابع صرفاً پل ارتباطی بین خروجی مدل و آن توابع است.
    """
    try:
        if name == "create_file":
            result = create_file(arguments["path"], arguments["content"])
            return json.dumps(result.__dict__, ensure_ascii=False)

        if name == "edit_file":
            result = edit_file(
                arguments["path"], arguments["content"], arguments.get("mode", "overwrite")
            )
            return json.dumps(result.__dict__, ensure_ascii=False)

        if name == "delete_file":
            result = delete_file(arguments["path"])
            return json.dumps(result.__dict__, ensure_ascii=False)

        if name == "run_code":
            result = run_code(
                code=arguments["code"],
                language=arguments["language"],
                sandbox_root=settings.sandbox_root,
                timeout_seconds=settings.sandbox_timeout,
            )
            return json.dumps(result.__dict__, ensure_ascii=False)

        if name == "web_search":
            result = web_search(
                query=arguments["query"], max_results=arguments.get("max_results", 5)
            )
            hits = [hit.__dict__ for hit in result.hits]
            payload = {
                "success": result.success,
                "query": result.query,
                "hits": hits,
                "error": result.error,
            }
            return json.dumps(payload, ensure_ascii=False)

        return json.dumps(
            {"success": False, "message": f"ابزار ناشناخته: '{name}'"}, ensure_ascii=False
        )

    except KeyError as exc:
        return json.dumps(
            {"success": False, "message": f"پارامتر ضروری وجود ندارد: {exc}"},
            ensure_ascii=False,
        )
    except Exception as exc:  # noqa: BLE001 - خطای غیرمنتظره را به مدل گزارش می‌کنیم، برنامه کرش نکند
        return json.dumps(
            {"success": False, "message": f"خطای غیرمنتظره در اجرای ابزار '{name}': {exc}"},
            ensure_ascii=False,
        )


def run_chat_loop(settings: Settings) -> None:
    """حلقه اصلی چت تعاملی با کاربر در ترمینال."""
    client = OpenAI(api_key=settings.api_key, base_url=settings.base_url)

    messages: list[Message] = [
        {"role": "system", "content": build_system_prompt()},
    ]

    console.print(
        f"[bold cyan]دستیار هوش مصنوعی ترموکس آماده است[/bold cyan] "
        f"(مدل: {settings.model})\n"
        "برای خروج بنویس: exit یا quit\n"
    )

    while True:
        try:
            user_input = console.input("[bold green]شما:[/bold green] ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[cyan]خروج از دستیار. خدانگهدار![/cyan]")
            break

        if not user_input:
            continue
        if user_input.lower() in {"exit", "quit", "خروج"}:
            console.print("[cyan]خروج از دستیار. خدانگهدار![/cyan]")
            break

        messages.append({"role": "user", "content": user_input})

        for _ in range(settings.max_tool_iterations):
            try:
                response = client.chat.completions.create(
                    model=settings.model,
                    messages=messages,  # type: ignore[arg-type]
                    tools=TOOLS_SCHEMA,  # type: ignore[arg-type]
                )
            except APIError as exc:
                console.print(f"[red]خطای API: {exc}[/red]")
                break
            except Exception as exc:  # noqa: BLE001
                console.print(f"[red]خطای غیرمنتظره در ارتباط با مدل: {exc}[/red]")
                break

            choice = response.choices[0]
            assistant_message = choice.message

            # پیام کامل دستیار (شامل tool_calls) باید عیناً به تاریخچه اضافه شود
            messages.append(assistant_message.model_dump(exclude_none=True))

            tool_calls = assistant_message.tool_calls
            if not tool_calls:
                if assistant_message.content:
                    console.print("[bold magenta]دستیار:[/bold magenta]")
                    console.print(Markdown(assistant_message.content))
                break

            for tool_call in tool_calls:
                fn_name = tool_call.function.name
                try:
                    fn_args = json.loads(tool_call.function.arguments or "{}")
                except json.JSONDecodeError:
                    fn_args = {}

                console.print(f"[dim]→ فراخوانی ابزار: {fn_name}({fn_args})[/dim]")
                tool_result = _dispatch_tool_call(fn_name, fn_args, settings)

                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": tool_result,
                    }
                )
            # بعد از اجرای ابزار(ها)، دوباره به مدل برمی‌گردیم تا پاسخ نهایی/گام بعدی را بدهد
        else:
            console.print(
                "[yellow]به سقف تعداد فراخوانی ابزار در این نوبت رسیدیم؛ "
                "لطفاً درخواست را دقیق‌تر یا کوچک‌تر بیان کن.[/yellow]"
            )


def main() -> None:
    settings = load_settings()
    run_chat_loop(settings)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
