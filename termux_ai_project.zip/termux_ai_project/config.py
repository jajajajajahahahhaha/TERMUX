"""
config.py
----------
مدیریت متمرکز پیکربندی و متغیرهای محیطی پروژه.
هیچ توکن یا کلید API هرگز داخل کد هاردکد نمی‌شود؛ همه چیز از
متغیرهای محیطی (Environment Variables) یا فایل .env خوانده می‌شود.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from typing import Final

try:
    from dotenv import load_dotenv

    load_dotenv()  # اگر فایل .env در پوشه پروژه موجود باشد، بارگذاری می‌شود
except ImportError:
    # python-dotenv اختیاری است؛ اگر نصب نباشد فقط از env واقعی سیستم می‌خوانیم
    pass

DEFAULT_BASE_URL: Final[str] = "https://api.minimax.io/v1"
DEFAULT_MODEL: Final[str] = "MiniMax-M2.7"
DEFAULT_TIMEOUT_SECONDS: Final[int] = 60
DEFAULT_SANDBOX_TIMEOUT_SECONDS: Final[int] = 30
DEFAULT_MAX_TOOL_ITERATIONS: Final[int] = 12


@dataclass(frozen=True, slots=True)
class Settings:
    """پیکربندی نهایی و اعتبارسنجی‌شده اپلیکیشن."""

    api_key: str
    base_url: str
    model: str
    request_timeout: int
    sandbox_timeout: int
    max_tool_iterations: int
    sandbox_root: str


def load_settings() -> Settings:
    """
    تنظیمات را از متغیرهای محیطی می‌خواند.
    در صورت نبود کلید API، پیام خطای واضح می‌دهد و برنامه را متوقف می‌کند
    (به جای کرش با Traceback نامشخص).
    """
    api_key = os.environ.get("MINIMAX_API_KEY", "").strip()
    if not api_key:
        sys.stderr.write(
            "\n❌ خطا: متغیر محیطی MINIMAX_API_KEY تنظیم نشده است.\n"
            "لطفاً در ترموکس اجرا کنید:\n\n"
            "    export MINIMAX_API_KEY='کلید-واقعی-شما'\n\n"
            "یا آن را در فایل .env (کنار main.py) قرار دهید:\n"
            "    MINIMAX_API_KEY=کلید-واقعی-شما\n\n"
            "⚠️  هرگز کلید API خودتان را در چت یا کد به اشتراک نگذارید.\n"
        )
        sys.exit(1)

    base_url = os.environ.get("MINIMAX_BASE_URL", DEFAULT_BASE_URL).strip()
    model = os.environ.get("MINIMAX_MODEL", DEFAULT_MODEL).strip()

    sandbox_root = os.environ.get(
        "TERMUX_AI_SANDBOX_DIR",
        os.path.join(os.path.expanduser("~"), "termux_ai_sandbox"),
    )
    os.makedirs(sandbox_root, exist_ok=True)

    return Settings(
        api_key=api_key,
        base_url=base_url,
        model=model,
        request_timeout=int(os.environ.get("MINIMAX_TIMEOUT", DEFAULT_TIMEOUT_SECONDS)),
        sandbox_timeout=int(
            os.environ.get("SANDBOX_TIMEOUT", DEFAULT_SANDBOX_TIMEOUT_SECONDS)
        ),
        max_tool_iterations=int(
            os.environ.get("MAX_TOOL_ITERATIONS", DEFAULT_MAX_TOOL_ITERATIONS)
        ),
        sandbox_root=sandbox_root,
    )
